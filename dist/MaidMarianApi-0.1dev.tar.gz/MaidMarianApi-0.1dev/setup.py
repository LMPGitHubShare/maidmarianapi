from distutils.core import setup


setup(
    name='MaidMarianApi',
    version='0.1dev',
    packages=['maidmarianapi',],
    license='Creative Commons Attribution-Noncommercial-Share Alike license',
    long_description=open('README.txt').read(),
)